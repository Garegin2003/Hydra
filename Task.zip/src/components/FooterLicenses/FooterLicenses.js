import React from "react";

const FooterLicenses = () => {

    return (
        <div>
            <a href="#">
                <h2>
                    F.A.Q
                    <br />
                    <br />
                    SITEMAP
                    <br />
                    <br />
                    CONDITIONS
                    <br />
                    <br />
                    LICENSES
                </h2>
            </a>
        </div>
    )
}

export default FooterLicenses