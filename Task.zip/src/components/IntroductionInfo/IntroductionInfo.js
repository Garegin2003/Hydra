import React from "react";

const IntroductionInfo = () => {

    return <p>Vitae sapien pellentesque habitant morbi tristique senectus et netus et. Feugiat 
    nibh sed pulvinar proin gravida hendrerit lectus. Mi sit amet mauris commodo 
    quis imperdiet massa tincidunt nunc. Viverra aliquet eget sit amet tellus. Ornare 
    lectus sit amet est placerat in. Lectus magna fringilla urna porttitor rhoncus vitae.</p>
}

export default IntroductionInfo