import React from "react";

const FooterContent = () => {

    return (
        <a href="#">
            <h2>
                ABOUT
                <br />
                <br />
                SERVICES
                <br />
                <br />
                TECHNOLOGIES
                <br />
                <br />
                HOW TO
                <br />
                <br />
                JOIN HYDRA
            </h2>
        </a>
    )
}

export default FooterContent