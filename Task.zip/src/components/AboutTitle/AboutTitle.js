import React from "react";

const AboutTitle = () => {

    return (
        <div className="about_hydra_title">
            <h2>ABOUT</h2>
            <h3>HYDRA VR</h3>
        </div>
    )
}

export default AboutTitle