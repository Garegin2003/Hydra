import React from "react";
import arrow from "../../img/arrowB.png"

const BuildHydra = () => {

    return (
        <div className="build_hydra">
            <h2>WHY BUILD</h2>
            <div className="hydra">
                <h3>WITH HYDRA?</h3>
                <img src={arrow} />
            </div>
        </div>
    )
}

export default BuildHydra